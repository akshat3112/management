/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project;
import java.sql.*;

/**
 *
 * @author asus
 */
public class connectionprovider {

    /**
     *
     * @return
     */
    public static Connection getcon(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bbms","root","ketanmax@j20");
            return con;
        } catch (Exception e) {
            return null;}
    }
    
}
